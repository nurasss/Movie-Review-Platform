document.addEventListener("DOMContentLoaded", () => {
    const favCount = document.getElementById("favCount");
    const lastLogin = document.getElementById("lastLogin");
    const userStatus = document.getElementById("userStatus");

    const favoriteMovies = JSON.parse(localStorage.getItem("favoriteMovies")) || [];
    favCount.textContent = favoriteMovies.length;

    const currentUser = JSON.parse(localStorage.getItem("currentUser"));
    userStatus.textContent = currentUser && currentUser.fullName ? currentUser.fullName : "Guest";

    const loginTime = localStorage.getItem("lastLogin");
    lastLogin.textContent = loginTime ? new Date(loginTime).toLocaleString() : "Not logged in";
});