document.addEventListener("DOMContentLoaded", () => {
    const API_KEY = "ВАШ_API_KEY"; // Замените на реальный ключ
    const fetchMoviesBtn = document.getElementById("fetchMovies");
    const moviesList = document.getElementById("moviesList");
    
    // Функция для отображения сообщений
    function showAlert(message, type) {
        moviesList.innerHTML = `
            <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        `;
    }
    
    // Основная функция загрузки фильмов
    async function loadMovies() {
        try {
            // Показываем состояние загрузки
            fetchMoviesBtn.disabled = true;
            fetchMoviesBtn.innerHTML = `
                <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                Loading...
            `;
            
            // Выполняем запрос к API
            const response = await fetch(
    "https://api.themoviedb.org/3/movie/popular?api_key=88849047ba3351d64ea4fae7dc37495ff&language=en-US&page=1"
);
            // Обработка ошибок HTTP
            if (!response.ok) {
                throw new Error(`API error: ${response.status} ${response.statusText}`);
            }
            
            const data = await response.json();
            
            // Очищаем предыдущие результаты
            moviesList.innerHTML = '';
            
            // Проверяем наличие фильмов
            if (!data.results || data.results.length === 0) {
                showAlert("No movies found", "warning");
                return;
            }
            
            // Отображаем первые 6 фильмов
            data.results.slice(0, 6).forEach(movie => {
                const movieCard = document.createElement('div');
                movieCard.className = 'col-md-4 mb-4';
                movieCard.innerHTML = `
                    <div class="card h-100 movie-card" role="article" aria-labelledby="title-${movie.id}">
                        <img src="https://image.tmdb.org/t/p/w500${movie.poster_path}" 
                             class="card-img-top" 
                             alt="${movie.title} poster"
                             loading="lazy">
                        <div class="card-body">
                            <h5 class="card-title" id="title-${movie.id}">${movie.title}</h5>
                            <div class="rating-badge">
                                <i class="fas fa-star me-1"></i>${movie.vote_average}
                            </div>
                            <p class="card-text">${movie.overview.substring(0, 100)}...</p>
                            <div class="d-flex justify-content-between">
                                <button class="btn btn-sm btn-outline-primary toggle-favorite" 
                                        data-id="${movie.id}"
                                        data-title="${movie.title}"
                                        aria-label="Add ${movie.title} to favorites">
                                    <i class="far fa-heart"></i> Favorite
                                </button>
                                <span class="text-muted small">
                                    ${new Date(movie.release_date).getFullYear()}
                                </span>
                            </div>
                        </div>
                    </div>
                `;
                moviesList.appendChild(movieCard);
            });
        } catch (error) {
            console.error("Movies loading error:", error);
            showAlert(`Failed to load movies: ${error.message}`, "danger");
        } finally {
            // Восстанавливаем кнопку
            fetchMoviesBtn.disabled = false;
            fetchMoviesBtn.textContent = "Load Movies";
        }
    }
    
    // Обработчик клика для кнопки
    fetchMoviesBtn.addEventListener("click", loadMovies);
    
    // Обработчик для добавления в избранное
    moviesList.addEventListener("click", (e) => {
        if (e.target.classList.contains("toggle-favorite")) {
            const btn = e.target.closest(".toggle-favorite");
            const movieId = btn.dataset.id;
            const movieTitle = btn.dataset.title;
            
            // Получаем текущие избранные фильмы
            let favorites = JSON.parse(localStorage.getItem("favoriteMovies")) || [];
            
            // Проверяем, есть ли уже фильм в избранном
            const isFavorite = favorites.includes(movieId);
            
            if (isFavorite) {
                // Удаляем из избранного
                favorites = favorites.filter(id => id !== movieId);
                btn.innerHTML = '<i class="far fa-heart"></i> Favorite';
                btn.classList.replace("btn-primary", "btn-outline-primary");
                showAlert(`"${movieTitle}" removed from favorites`, "info");
            } else {
                // Добавляем в избранное
                favorites.push(movieId);
                btn.innerHTML = '<i class="fas fa-heart"></i> Favorited';
                btn.classList.replace("btn-outline-primary", "btn-primary");
                showAlert(`"${movieTitle}" added to favorites!`, "success");
            }
            
            // Сохраняем обновлённый список
            localStorage.setItem("favoriteMovies", JSON.stringify(favorites));
        }
    });
    
    // Загружаем фильмы при первом открытии страницы
    loadMovies();
});