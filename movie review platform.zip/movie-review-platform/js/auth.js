document.addEventListener("DOMContentLoaded", () => {
    const users = JSON.parse(localStorage.getItem("users")) || [];

    // Register Form
    const registerForm = document.getElementById("registerForm");
    const registerMessage = document.getElementById("registerMessage");
    if (registerForm) {
        registerForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const fullName = document.getElementById("fullName").value.trim();
            const email = document.getElementById("registerEmail").value.trim();
            const password = document.getElementById("registerPassword").value.trim();

            if (!fullName || !email || !password) {
                registerMessage.innerHTML = '<div class="alert alert-danger">All fields are required.</div>';
                return;
            }
            if (users.some(user => user.email === email)) {
                registerMessage.innerHTML = '<div class="alert alert-danger">Email already registered.</div>';
                return;
            }

            users.push({ fullName, email, password, lastLogin: new Date().toISOString() });
            localStorage.setItem("users", JSON.stringify(users));
            registerMessage.innerHTML = '<div class="alert alert-success">Registration successful! You can now log in.</div>';
            registerForm.reset();
        });
    }

    // Login Form
    const loginForm = document.getElementById("loginForm");
    const loginMessage = document.getElementById("loginMessage");
    if (loginForm) {
        loginForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const email = document.getElementById("loginEmail").value.trim();
            const password = document.getElementById("loginPassword").value.trim();

            const user = users.find(u => u.email === email && u.password === password);
            if (user) {
                user.lastLogin = new Date().toISOString();
                localStorage.setItem("users", JSON.stringify(users));
                localStorage.setItem("currentUser", JSON.stringify(user));
                loginMessage.innerHTML = '<div class="alert alert-success">Login successful! Redirecting...</div>';
                setTimeout(() => window.location.href = "dashboard.html", 1000);
            } else {
                loginMessage.innerHTML = '<div class="alert alert-danger">Invalid email or password.</div>';
            }
        });
    }
});