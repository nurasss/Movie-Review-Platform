document.addEventListener("DOMContentLoaded", () => {
    // Featured Movie Object
    const featuredMovie = {
        title: "Inception",
        image: "images/inception.webp",
        description: "A mind-bending sci-fi thriller.",
        updateMovie(newTitle, newImage, newDescription) {
            this.title = newTitle;
            this.image = newImage;
            this.description = newDescription;
            document.getElementById("welcomeMessage").textContent = `Featured: ${this.title}`;
            document.getElementById("featuredImage").src = this.image;
            document.getElementById("featuredDescription").textContent = this.description;
        }
    };

    // Higher-Order Function
    function handleInteraction(action, callback) {
        return function(event) {
            callback(event);
            action();
        };
    }

    // Sound Playback
    const clickSound = new Audio("images/sound.mp3");

    // Select and Style Elements
    const welcomeMessage = document.getElementById("welcomeMessage");
    const movieListItems = document.getElementsByClassName("list-group-item");
    const featuredImage = document.querySelector("#featuredImage");

    if (welcomeMessage) {
        welcomeMessage.style.backgroundColor = getComputedStyle(document.documentElement).getPropertyValue("--gold");
        welcomeMessage.style.padding = "10px";
    }

    if (movieListItems.length > 0) {
        movieListItems[0].style.fontSize = "1.2rem";
    }

    if (featuredImage) {
        featuredImage.style.display = "block";
        featuredImage.setAttribute("loading", "lazy");
        featuredImage.setAttribute("alt", "Featured movie poster");
    }

    // Welcome Message with User Check
    const currentUser = JSON.parse(localStorage.getItem("currentUser"));
    if (welcomeMessage) {
        welcomeMessage.textContent = currentUser && currentUser.fullName ? `Welcome, ${currentUser.fullName}!` : "Welcome to MoviePlatform!";
    }

    // Random Rating
    const generateRatingBtn = document.getElementById("generateRating");
    const ratingResult = document.getElementById("ratingResult");
    if (generateRatingBtn && ratingResult) {
        generateRatingBtn.addEventListener("click", () => {
            const rating = Math.floor(Math.random() * 100) + 1;
            const isEven = rating % 2 === 0;
            const isAbove50 = rating > 50;
            ratingResult.innerHTML = `
                <div class="alert alert-info">
                    Generated Rating: <strong>${rating}</strong><br>
                    The rating is <strong>${isEven ? "even" : "odd"}</strong>.<br>
                    The rating is <strong>${isAbove50 ? "above" : "below or equal to"} 50</strong>.
                </div>
            `;
        });
    }

    // Compare Ratings
    const compareRatingsBtn = document.getElementById("compareRatings");
    const movieARatingInput = document.getElementById("movieARating");
    const movieBRatingInput = document.getElementById("movieBRating");
    const compareResult = document.getElementById("compareResult");
    if (compareRatingsBtn && compareResult) {
        compareRatingsBtn.addEventListener("click", () => {
            const ratingA = parseInt(movieARatingInput.value);
            const ratingB = parseInt(movieBRatingInput.value);
            if (isNaN(ratingA) || isNaN(ratingB) || ratingA < 1 || ratingA > 100 || ratingB < 1 || ratingB > 100) {
                compareResult.innerHTML = '<div class="alert alert-danger">Please enter valid ratings between 1 and 100.</div>';
                return;
            }
            let message = "";
            if (ratingA > ratingB) message = "Movie A has a higher rating than Movie B.";
            else if (ratingA < ratingB) message = "Movie B has a higher rating than Movie A.";
            else if (ratingA === ratingB && ratingA >= 80) message = "Both movies have the same high rating (80 or above)!";
            else message = "Both movies have the same rating.";
            compareResult.innerHTML = `<div class="alert alert-info">${message}</div>`;
        });
    }

    // Show Message Function
    function showMessage(elementId, message, type) {
        const element = document.getElementById(elementId);
        if (element) {
            element.innerHTML = `
                <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            `;
        }
    }

    // Favorite Movies with localStorage
    let favoriteMovies = JSON.parse(localStorage.getItem("favoriteMovies")) || ["Inception", "Interstellar", "Dune"];
    const movieList = document.getElementById("movieList");
    const newMovieInput = document.getElementById("newMovie");
    const addMovieBtn = document.getElementById("addMovie");
    const clearMoviesBtn = document.getElementById("clearMovies");

    function renderMovieList() {
        if (movieList) {
            movieList.innerHTML = "";
            favoriteMovies.forEach((movie) => {
                const li = document.createElement("li");
                li.className = "list-group-item clickable";
                li.textContent = movie;
                movieList.appendChild(li);
            });
            localStorage.setItem("favoriteMovies", JSON.stringify(favoriteMovies));
        }
    }

    if (movieList) {
        renderMovieList();
        movieList.addEventListener("click", (e) => {
            if (e.target.classList.contains("list-group-item")) {
                const index = favoriteMovies.indexOf(e.target.textContent);
                if (index > -1) {
                    favoriteMovies.splice(index, 1);
                    clickSound.play();
                    renderMovieList();
                    showMessage("movieMessage", "Фильм удалён из списка.", "info");
                }
            }
        });
        movieList.addEventListener("mouseover", () => {
            movieList.style.backgroundColor = getComputedStyle(document.documentElement).getPropertyValue("--primary-dark");
        });
        movieList.addEventListener("mouseout", () => {
            movieList.style.backgroundColor = "";
        });
    }

    if (addMovieBtn && newMovieInput) {
        addMovieBtn.addEventListener("click", () => {
            const newMovie = newMovieInput.value.trim();
            if (!newMovie) {
                showMessage("movieMessage", "Пожалуйста, введите название фильма.", "danger");
                return;
            }
            if (favoriteMovies.includes(newMovie)) {
                showMessage("movieMessage", "Этот фильм уже есть в вашем списке!", "danger");
                newMovieInput.value = "";
                return;
            }
            favoriteMovies.push(newMovie);
            clickSound.play();
            renderMovieList();
            newMovieInput.value = "";
            showMessage("movieMessage", "Фильм успешно добавлен!", "success");
        });
    }

    if (clearMoviesBtn) {
        clearMoviesBtn.addEventListener("click", () => {
            favoriteMovies = [];
            clickSound.play();
            renderMovieList();
            showMessage("movieMessage", "Список любимых фильмов очищен!", "info");
        });
    }

    // Recommended Movies
    const recommendedMovies = [
        "The Matrix", "Blade Runner", "Star Wars", "The Dark Knight", "Pulp Fiction",
        "Fight Club", "Forrest Gump", "The Shawshank Redemption", "Gladiator", "Titanic"
    ];
    const recommendedList = document.getElementById("recommendedMovies");
    if (recommendedList) {
        for (let i = 0; i < recommendedMovies.length; i++) {
            const li = document.createElement("li");
            li.className = `list-group-item ${i % 2 === 0 ? "bg-even" : "bg-odd"}`;
            li.textContent = recommendedMovies[i];
            recommendedList.appendChild(li);
        }
    }

    // Event Listeners
    const changeImageBtn = document.getElementById("changeImage");
    if (changeImageBtn) {
        changeImageBtn.addEventListener("click", handleInteraction(
            () => clickSound.play(),
            () => {
                featuredMovie.updateMovie("Interstellar", "images/inter.webp", "A journey through space and time.");
            }
        ));
    }

    const toggleWelcomeBtn = document.getElementById("toggleWelcome");
    if (toggleWelcomeBtn && welcomeMessage) {
        toggleWelcomeBtn.addEventListener("dblclick", () => {
            welcomeMessage.textContent = welcomeMessage.textContent.includes("Featured")
                ? (currentUser && currentUser.fullName ? `Welcome, ${currentUser.fullName}!` : "Welcome to MoviePlatform!")
                : `Featured: ${featuredMovie.title}`;
        });
    }

    // Highlight Section
    const highlightBtn = document.getElementById("highlight");
    if (highlightBtn) {
        highlightBtn.addEventListener("click", () => {
            highlightBtn.style.backgroundColor = "#ffd369";
            highlightBtn.style.color = "#1a1a2e";
            highlightBtn.style.padding = "8px";
            highlightBtn.style.borderRadius = "4px";
        });
    }

    // Add Review via Modal
    const submitReviewBtn = document.getElementById("submitReview");
    const userReviewInput = document.getElementById("userReview");
    const reviewsList = document.getElementById("reviews");
    if (submitReviewBtn && userReviewInput && reviewsList) {
        submitReviewBtn.addEventListener("click", () => {
            const userReview = userReviewInput.value.trim();
            if (userReview) {
                const li = document.createElement("li");
                li.className = "list-group-item";
                li.textContent = userReview;
                reviewsList.appendChild(li);
                userReviewInput.value = "";
                const reviewModal = bootstrap.Modal.getInstance(document.getElementById("reviewModal"));
                reviewModal.hide();
            } else {
                showMessage("movieMessage", "Please enter a review.", "danger");
            }
        });
    }

    // Add Genre via Modal
    const submitGenreBtn = document.getElementById("submitGenre");
    const newGenreInput = document.getElementById("newGenre");
    const genreList = document.getElementById("genreList");
    if (submitGenreBtn && newGenreInput && genreList) {
        submitGenreBtn.addEventListener("click", () => {
            const newGenre = newGenreInput.value.trim();
            if (newGenre) {
                const li = document.createElement("li");
                li.className = "list-group-item";
                li.textContent = newGenre;
                genreList.appendChild(li);
                newGenreInput.value = "";
                const genreModal = bootstrap.Modal.getInstance(document.getElementById("genreModal"));
                genreModal.hide();
            } else {
                showMessage("movieMessage", "Please enter a genre.", "danger");
            }
        });
    }

    // API Integration for Movies Page
    const loadMoviesBtn = document.getElementById("loadMovies");
    const movieGrid = document.getElementById("movieGrid");
    if (loadMoviesBtn && movieGrid) {
        loadMoviesBtn.addEventListener("click", async () => {
            try {
                const response = await fetch(
                    "https://api.themoviedb.org/3/movie/popular?api_key=YOUR_API_KEY&language=en-US&page=1"
                );
                if (!response.ok) throw new Error("Failed to fetch movies");
                const data = await response.json();
                movieGrid.innerHTML = "";
                data.results.slice(0, 6).forEach((movie) => {
                    const card = document.createElement("div");
                    card.className = "col-md-4 mb-4";
                    card.innerHTML = `
                        <article class="card movie-card clickable" data-bs-toggle="modal" data-bs-target="#movieModal"
                            data-title="${movie.title}" data-image="https://image.tmdb.org/t/p/w500${movie.poster_path}"
                            data-description="${movie.overview}" data-rating="${(movie.vote_average * 10).toFixed(1)}">
                            <img src="https://image.tmdb.org/t/p/w500${movie.poster_path}" class="card-img-top" alt="${movie.title} poster" loading="lazy">
                            <div class="card-body">
                                <h5 class="card-title">${movie.title}</h5>
                                <p class="card-text">Rating: ${(movie.vote_average * 10).toFixed(1)}</p>
                            </div>
                        </article>
                    `;
                    movieGrid.appendChild(card);
                });
                showMessage("movieMessage", "Movies loaded successfully!", "success");

                movieGrid.addEventListener("click", (e) => {
                    const card = e.target.closest(".movie-card");
                    if (card) {
                        document.getElementById("movieModalLabel").textContent = card.dataset.title;
                        document.getElementById("modalImage").src = card.dataset.image;
                        document.getElementById("modalImage").alt = `${card.dataset.title} poster`;
                        document.getElementById("modalDescription").textContent = card.dataset.description;
                        document.getElementById("modalRating").textContent = `Rating: ${card.dataset.rating}`;
                    }
                });
            } catch (error) {
                showMessage("movieMessage", "Error loading movies: " + error.message, "danger");
            }
        });
    }

    // Dashboard Updates
    const userGreeting = document.getElementById("userGreeting");
    const lastLogin = document.getElementById("lastLogin");
    if (userGreeting && lastLogin) {
        if (currentUser) {
            userGreeting.textContent = `Welcome, ${currentUser.fullName}!`;
            lastLogin.textContent = `Last login: ${new Date(currentUser.lastLogin).toLocaleString()}`;
        } else {
            userGreeting.textContent = "Please log in to see your dashboard.";
            lastLogin.textContent = "";
        }
    }
});